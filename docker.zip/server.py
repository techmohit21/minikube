import socket

HOST = 'localhost'
PORT = 8000

def handle_request(client_socket):
    request = client_socket.recv(1024).decode('utf-8')
    # Extract the requested file path from the HTTP request
    file_path = request.split()[1][1:]
    
    try:
        with open(file_path, 'rb') as file:
            response_body = file.read()
            response_header = 'HTTP/1.1 200 OK\r\nContent-Length: {}\r\n\r\n'.format(len(response_body))
            client_socket.sendall(response_header.encode('utf-8') + response_body)
    except FileNotFoundError:
        response_header = 'HTTP/1.1 404 Not Found\r\n\r\n'
        response_body = b'404 Not Found'
        client_socket.sendall(response_header.encode('utf-8') + response_body)

def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind((HOST, PORT))
    server_socket.listen(1)
    print('Server running on http://{}:{}'.format(HOST, PORT))

    try:
        while True:
            client_socket, client_address = server_socket.accept()
            print('Received connection from {}:{}'.format(client_address[0], client_address[1]))
            handle_request(client_socket)
            client_socket.close()
    except KeyboardInterrupt:
        server_socket.close()
        print('Server stopped')

if __name__ == '__main__':
    start_server()