import redis
import socket
import random 
import string

print("hello")
# Connect to Redis
redis_host = 'redis-18236.c305.ap-south-1-1.ec2.cloud.redislabs.com'  # Redis server hostname
redis_port = 18236  # Redis server port number
redis_db = 0  # Redis database number
redis_password = 'a86oHclR14XVTJgo517YD4aasYGVSYD7'  # Redis server password

def random_string(length=10):
    letters = string.ascii_lowercase
    return ''.join(random.choice(letters) for i in range(length))

try:
    # Create a Redis connection
    redis_conn = redis.Redis(host=redis_host, port=redis_port, db=redis_db, password=redis_password)

    # Test the connection
    pong = redis_conn.ping()
    if pong:
        print("Connected")
    else:
       print("Connection Failed")

    for i in range(2000):
        redis_conn.set(random_string(), random_string())
        print("inserting"+str(i))
        
    print("done")

except redis.RedisError as e:
    print(f"Error connecting to Redis: {e}")



HOST = 'localhost'
PORT = 8000

def handle_request(client_socket):
    request = client_socket.recv(1024).decode('utf-8')
    # Extract the requested file path from the HTTP request
    file_path = request.split()[1][1:]
    
    try:
        with open(file_path, 'rb') as file:
            response_body = file.read()
            response_header = 'HTTP/1.1 200 OK\r\nContent-Length: {}\r\n\r\n'.format(len(response_body))
            client_socket.sendall(response_header.encode('utf-8') + response_body)
    except FileNotFoundError:
        response_header = 'HTTP/1.1 404 Not Found\r\n\r\n'
        response_body = b'404 Not Found'
        client_socket.sendall(response_header.encode('utf-8') + response_body)

def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind((HOST, PORT))
    server_socket.listen(1)
    print('Server running on http://{}:{}'.format(HOST, PORT))

    try:
        while True:
            client_socket, client_address = server_socket.accept()
            print('Received connection from {}:{}'.format(client_address[0], client_address[1]))
            handle_request(client_socket)
            client_socket.close()
    except KeyboardInterrupt:
        server_socket.close()
        print('Server stopped')

# if __name__ == '__main__':
#     start_server()